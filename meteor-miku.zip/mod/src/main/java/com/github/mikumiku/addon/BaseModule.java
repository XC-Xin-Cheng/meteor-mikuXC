package com.github.mikumiku.addon;

import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;
import com.github.mikumiku.addon.mixin.IClientWorld;
import com.github.mikumiku.addon.modules.AutoSM;
import com.github.mikumiku.addon.modules.MEnum;
import meteordevelopment.meteorclient.pathing.IPathManager;
import meteordevelopment.meteorclient.pathing.NopPathManager;
import meteordevelopment.meteorclient.pathing.PathManagers;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.prediction.BlockStatePredictionHandler;
import net.minecraft.client.multiplayer.prediction.PredictiveAction;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;

import static com.github.mikumiku.addon.util.ChatUtils.sendMsg;

public abstract class BaseModule extends Module implements MEnum {

    public static final Category CATEGORY_MIKU_BUILD = new Category("Miku 建设");
    public static final Category CATEGORY_MIKU_COMBAT = new Category("Miku 战斗");
    public static final Category CATEGORY_MIKU_PRO = new Category("Miku 特调");
    public static final Category CATEGORY = new Category("Miku");

    public Minecraft mc = Minecraft.getInstance();

    IBaritone baritone;

    public BaseModule(Category category, String name, String description, String... aliases) {
        super(category, name, description, aliases);
        mc = Minecraft.getInstance();
    }

    public BaseModule(Category category, String name, String desc) {
        super(category, name, desc);
        mc = Minecraft.getInstance();


        try {
            IPathManager pathManager = PathManagers.get();

            if (PathManagers.get() instanceof NopPathManager) {
                //noop
            } else {
                baritone = BaritoneAPI.getProvider().getPrimaryBaritone();
            }
        } catch (Exception e) {
            error("请安装Baritone!");
        }
    }

    public BaseModule(String name, String desc) {
        super(CATEGORY, name, desc);
    }


    @Override
    public void onActivate() {
        super.onActivate();
        if (mc == null) {
            mc = Minecraft.getInstance();
        }
        initBaritone();
        initMni();
        try {

            AutoSM sm = Modules.get().get(AutoSM.class);
            if (sm.auto.get()) {
                if (!sm.isActive()) {
                    sm.toggle();
                }
            }
        } catch (Exception e) {

        }
    }

    private void initMinihud() {

        System.out.println("324");
    }

    private void initMni() {

        System.out.println("ws");
    }

    private void initBaritone() {

        try {

            try {
                if (PathManagers.get() instanceof NopPathManager) {
                    //noop
                } else {
                    baritone = BaritoneAPI.getProvider().getPrimaryBaritone();
                }
            } catch (Exception e) {
                error("请安装Baritone!");
            }
        } catch (Exception e) {

        }
    }

    public void sendToggledMsg() {
        Component onMsg = Component.empty().setStyle(Style.EMPTY.applyFormat(ChatFormatting.GREEN)).append("ON");
        Component offMsg = Component.empty().setStyle(Style.EMPTY.applyFormat(ChatFormatting.RED)).append("OFF");
        ChatUtils.forceNextPrefixClass(getClass());
        MutableComponent toggledMsg = Component.empty();
        toggledMsg.append(Component.empty().setStyle(Style.EMPTY.applyFormat(ChatFormatting.WHITE)).append(title));
        toggledMsg.append(" ");
        toggledMsg.append(Component.empty().setStyle(Style.EMPTY.applyFormat(ChatFormatting.GRAY)).append("toggled "));
        toggledMsg.append((isActive() ? onMsg : offMsg));

        sendMsg(toggledMsg, hashCode());
    }


    public static void sendSequencedPacket(PredictiveAction packetCreator) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.getConnection() == null || mc.level == null) return;
        try (BlockStatePredictionHandler pendingUpdateManager = ((IClientWorld) mc.level).getPendingManager().startPredicting()) {
            int i = pendingUpdateManager.currentSequence();
            mc.getConnection().send(packetCreator.predict(i));
        }
    }
}
