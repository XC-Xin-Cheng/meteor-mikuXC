package com.github.mikumiku.addon.mixin;

import meteordevelopment.meteorclient.systems.modules.render.blockesp.ESPChunk;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.chunk.ChunkAccess;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

import static meteordevelopment.meteorclient.MeteorClient.mc;

/**
 * Mixin
 */
@Mixin(ESPChunk.class)
public abstract class BlockESPMixin {
    // 上游用 lombok @Slf4j，此处等价展开为显式字段
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(BlockESPMixin.class);


    @Inject(method = "searchChunk",
        at = @At("HEAD"), cancellable = true)
    private static void injectSearchChunk(ChunkAccess chunk, List<Block> blocks, CallbackInfoReturnable<ESPChunk> cir) {
        try {
            ESPChunk schunk = new ESPChunk(chunk.getPos().x(), chunk.getPos().z());
            if (schunk.shouldBeDeleted()) {
                cir.setReturnValue(schunk);
                return;
            }

            BlockPos.MutableBlockPos blockPos = new BlockPos.MutableBlockPos();
            BlockPos playerPos = mc.player.blockPosition();

            for (int x = chunk.getPos().getMinBlockX(); x <= chunk.getPos().getMaxBlockX(); x++) {
                for (int z = chunk.getPos().getMinBlockZ(); z <= chunk.getPos().getMaxBlockZ(); z++) {
                    int height = chunk.getOrCreateHeightmapUnprimed(Heightmap.Types.WORLD_SURFACE).getFirstAvailable(x - chunk.getPos().getMinBlockX(), z - chunk.getPos().getMinBlockZ());

                    for (int y = mc.level.getMinY(); y < height; y++) {
                        blockPos.set(x, y, z);
                        BlockState bs = chunk.getBlockState(blockPos);
                        Block block = bs.getBlock();

                        if (blocks.contains(block)) {
                            if (block instanceof LiquidBlock) {
                                Integer level = bs.getValue(LiquidBlock.LEVEL);
                                if (level != null && level == 0) {
                                    // 水源距离限制
                                    if (block == Blocks.WATER) {
                                        double distanceSq = net.minecraft.world.phys.Vec3.atLowerCornerOf(blockPos).distanceToSqr(net.minecraft.world.phys.Vec3.atLowerCornerOf(playerPos));
                                        if (distanceSq > (64 * 64)) continue; // 跳过渲染
                                    }
                                    schunk.add(blockPos, false);
                                }
                            } else {
                                schunk.add(blockPos, false);
                            }
                        }
                    }
                }
            }

            cir.setReturnValue(schunk);
        } catch (Exception e) {
            log.error("Miku BlockESPMixin.injectSearchChunk err: " + e);
        }
    }
}
