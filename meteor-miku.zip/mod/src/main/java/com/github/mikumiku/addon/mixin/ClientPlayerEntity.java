package com.github.mikumiku.addon.mixin;

import com.github.mikumiku.addon.mixinface.MoveEvent;
import com.mojang.authlib.GameProfile;
import meteordevelopment.meteorclient.MeteorClient;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = net.minecraft.client.player.LocalPlayer.class, priority = 800)
public abstract class ClientPlayerEntity extends AbstractClientPlayer {

    // 26.1：yarn 时代的 getPitch(float) 在官方映射里叫 getViewXRot(float)
    @Shadow
    public abstract float getViewXRot(float tickDelta);

    private ClientPlayerEntity(ClientLevel world, GameProfile profile) {
        super(world, profile);
    }

    @Inject(method = "move", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/AbstractClientPlayer;move(Lnet/minecraft/world/entity/MoverType;Lnet/minecraft/world/phys/Vec3;)V"), cancellable = true)
    public void onMoveHook(MoverType movementType, Vec3 movement, CallbackInfo ci) {
        MoveEvent event = new MoveEvent(movement.x, movement.y, movement.z);
        MeteorClient.EVENT_BUS.post(event);
        if (event.isCancelled()) {
            super.move(movementType, new Vec3(event.getX(), event.getY(), event.getZ()));
            ci.cancel();
        }
    }


//    @Inject(method = "sendMovementPackets", at = @At("HEAD"), cancellable = true)
//    private void sendMovementPacketsHook(CallbackInfo info) {
//        SyncEvent event = new SyncEvent(getYaw(), getPitch());
//        MeteorClient.EVENT_BUS.post(event);
//        if (event.isCancelled()) info.cancel();
//    }
}
