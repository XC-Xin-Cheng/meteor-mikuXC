package com.github.mikumiku.addon.mixin;

import com.github.mikumiku.addon.mixinface.MagicMix;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Pose;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.UUID;


@Mixin(Entity.class)
public class EntityMixin {
    @Shadow
    protected UUID uuid;


    @Inject(at = @At("HEAD"), method = "getPose()Lnet/minecraft/world/entity/Pose;", require = 0, cancellable = true)
    private void getPose(CallbackInfoReturnable<Pose> cir) {
        Minecraft mc = Minecraft.getInstance();
        if (MagicMix.eflyenabled() && this.uuid == mc.player.getUUID()) {
            cir.setReturnValue(Pose.STANDING);
        }
    }

    @Inject(at = @At("HEAD"), method = "isSprinting()Z", require = 0, cancellable = true)
    private void isSprinting(CallbackInfoReturnable<Boolean> cir) {
        Minecraft mc = Minecraft.getInstance();
        if (MagicMix.eflyenabled() && this.uuid == mc.player.getUUID()) {
            cir.setReturnValue(true);
        }
    }

    // 26.1：pushAwayFrom(Entity) 已改名为 push(Entity)，这里显式写描述符以免匹配到其它 push 重载
    @Inject(at = @At("HEAD"), method = "push(Lnet/minecraft/world/entity/Entity;)V", require = 0, cancellable = true)
    private void pushAwayFrom(Entity entity, CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && this.uuid == mc.player.getUUID() && MagicMix.eflyenabled() && !entity.getUUID().equals(this.uuid)) {
            ci.cancel();
        }
    }
}
