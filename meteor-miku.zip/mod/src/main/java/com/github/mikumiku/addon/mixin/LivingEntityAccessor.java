package com.github.mikumiku.addon.mixin;

import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({LivingEntity.class})
public interface LivingEntityAccessor {

    // 26.1：jumpingCooldown 在官方映射里叫 noJumpDelay
    @Accessor("noJumpDelay")
    int getJumpCooldown();

    @Accessor("noJumpDelay")
    void setJumpCooldown(int var1);
}
