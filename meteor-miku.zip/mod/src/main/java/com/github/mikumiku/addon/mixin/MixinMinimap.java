package com.github.mikumiku.addon.mixin;

import com.github.mikumiku.addon.mixinface.MagicMix;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xaero.hud.minimap.Minimap;
import xaero.hud.minimap.module.MinimapSession;

/**
 * 小地图
 */
@Pseudo
@Mixin(targets = "xaero.hud.minimap.info.render.InfoDisplayRenderer")
public class MixinMinimap {

    // Xaero 26.5.0（MC 26.1）的真实签名：render(MinimapSession, Minimap, int, int, BlockPos, int, int, float, GuiGraphicsExtractor)
    @Inject(method = "render", at = @At("HEAD"), require = 0)
    private void modifyPlayerPosForCompile(
        MinimapSession session,
        Minimap minimap,
        int height,
        int size,
        BlockPos playerPos,
        int scaledX,
        int scaledY,
        float mapScale,
        GuiGraphicsExtractor guiGraphics,
        CallbackInfo ci) {

        if (MagicMix.coordinatesisActive()) {
            // 强转为 mutableBlockPos 并设置固定坐标值
            if (playerPos instanceof BlockPos.MutableBlockPos) {
                BlockPos.MutableBlockPos mutablePos = (BlockPos.MutableBlockPos) playerPos;
                mutablePos.set(MagicMix.x, playerPos.getY(), MagicMix.z); // 设置为固定坐标
            }
        }
    }
}
