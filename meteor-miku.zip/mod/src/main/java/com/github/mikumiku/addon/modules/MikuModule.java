package com.github.mikumiku.addon.modules;

import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;

import static com.github.mikumiku.addon.util.ChatUtils.sendMsg;

@SuppressWarnings("unused")
public class MikuModule extends Module {
    private boolean active;
    private final int priority;
    protected Minecraft mc = Minecraft.getInstance();


    public MikuModule(Category Category, String name, String desc) {
        super(Category, name, desc);
        this.priority = 100;
        mc = Minecraft.getInstance();

    }

    public void sendToggledMsg() {
        Component onMsg = Component.empty().setStyle(Style.EMPTY.applyFormat(ChatFormatting.GREEN)).append("ON");
        Component offMsg = Component.empty().setStyle(Style.EMPTY.applyFormat(ChatFormatting.RED)).append("OFF");
        ChatUtils.forceNextPrefixClass(getClass());
        MutableComponent toggledMsg = Component.empty();
        toggledMsg.append(Component.empty().setStyle(Style.EMPTY.applyFormat(ChatFormatting.WHITE)).append(title));
        toggledMsg.append(" ");
        toggledMsg.append(Component.empty().setStyle(Style.EMPTY.applyFormat(ChatFormatting.GRAY)).append("toggled "));
        toggledMsg.append((isActive() ? onMsg : offMsg));

        sendMsg(toggledMsg, hashCode());
    }

}
