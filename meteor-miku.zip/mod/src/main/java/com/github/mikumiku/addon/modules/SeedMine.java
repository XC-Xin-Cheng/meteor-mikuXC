package com.github.mikumiku.addon.modules;

import baritone.api.BaritoneAPI;
import baritone.api.utils.BetterBlockPos;
import com.github.mikumiku.addon.BaseModule;
import com.github.mikumiku.addon.mixinface.MagicMix;
import com.github.mikumiku.addon.util.Ore;
import com.github.mikumiku.addon.util.seeds.Seed;
import com.github.mikumiku.addon.util.seeds.Seeds;
import com.seedfinding.mccore.version.MCVersion;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.pathing.BaritoneUtils;
import meteordevelopment.meteorclient.pathing.NopPathManager;
import meteordevelopment.meteorclient.pathing.PathManagers;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.levelgen.WorldgenRandom;
import net.minecraft.world.level.levelgen.LegacyRandomSource;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.status.ChunkStatus;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class SeedMine extends BaseModule {

    private final Map<Long, Map<Ore, Set<Vec3>>> chunkRenderers = new ConcurrentHashMap<>();
    private Seed worldSeed = null;
    private Map<ResourceKey<Biome>, List<Ore>> oreConfig;
    public List<BlockPos> oreGoals = new ArrayList<>();
    private int tickCounter = 0;

    private final SettingGroup sgSeed = settings.createGroup("种子设置");
    private final Setting<String> seedInput = sgSeed.add(new StringSetting.Builder()
        .name("种子")
        .description("输入世界种子。（默认值为3C3U种子）")
        .defaultValue("-7346913998703726680")
        .build()
    );

    private final Setting<MCVersion> mcVersion = sgSeed.add(new EnumSetting.Builder<MCVersion>()
        .name("MC版本")
        .description("选择Minecraft版本")
        .defaultValue(MCVersion.v1_21)
        .build()
    );

    private final Setting<Boolean> applySeed = sgSeed.add(new BoolSetting.Builder()
        .name("应用种子")
        .description("点击应用上面设置的种子和版本")
        .defaultValue(false)
        .onChanged(this::onApplySeedChanged)
        .build()
    );

    private final SettingGroup sgGeneral = settings.getDefaultGroup();


    private final Setting<Integer> horizontalRadius = sgGeneral.add(new IntSetting.Builder()
        .name("区块范围")
        .description("显示区块的距离上限。")
        .defaultValue(5)
        .min(1)
        .sliderMax(10)
        .build()
    );


    private final Setting<Boolean> baritone = sgGeneral.add(new BoolSetting.Builder()
        .name("同步设置baritone" + (BaritoneUtils.IS_AVAILABLE ? "（OK）" : "（没找到）"))
        .description("将baritone矿物位置设置为种子算出的实际位置。")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> directMine = sgGeneral.add(new BoolSetting.Builder()
        .name("直接开挖")
        .description("不建议使用，除非实在不会命令")
        .defaultValue(false)
        .build()
    );
    private final Setting<Boolean> low = sgGeneral.add(new BoolSetting.Builder()
        .name("仅挖残骸密集区")
        .description("远古残骸在 Y=8~24 层最集中，挖掘效率最高，我们就挖这些。")
        .defaultValue(false)
        .build()
    );
    private final Setting<Boolean> diamond = sgGeneral.add(new BoolSetting.Builder()
        .name("仅挖钻石密集区")
        .description("钻石残骸在 Y=-58~-10 层最集中，挖掘效率最高，我们就挖这些。")
        .defaultValue(false)
        .build()
    );

    private final Setting<Integer> updateInterval = sgGeneral.add(new IntSetting.Builder()
        .name("更新间隔")
        .description("设置目标的间隔时间（秒）")
        .defaultValue(1)
        .min(1)
        .max(10)
        .sliderMax(10)
        .build()
    );


    public SeedMine() {
        super(CATEGORY_MIKU_BUILD, "种子矿透", "种子透视增强版。输入种子，算出矿物实际位置。注意必须使用基于彗星版的男中音。基于meteor_rejects");
        SettingGroup sgOres = settings.createGroup("矿物");
        Ore.oreSettings.forEach(sgOres::add);
    }

    public boolean baritone() {
        return isActive() && baritone.get() && isBaritonePresent();
    }

    public static boolean isBaritonePresent() {
        try {
            Class.forName("baritone.api.BaritoneAPI", false, ClassLoader.getSystemClassLoader());
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        } catch (Throwable t) {
            // 某些情况下 BaritoneAPI 类存在但初始化失败（例如循环依赖），也要视为不可用
            return false;
        }
    }


    @EventHandler
    private void onRender(Render3DEvent event) {
        if (mc.player == null || oreConfig == null) {
            return;
        }
        if (Seeds.get().getSeed() != null) {
            int chunkX = mc.player.chunkPosition().x();
            int chunkZ = mc.player.chunkPosition().z();

            int rangeVal = horizontalRadius.get();
            for (int range = 0; range <= rangeVal; range++) {
                for (int x = -range + chunkX; x <= range + chunkX; x++) {
                    renderChunk(x, chunkZ + range - rangeVal, event);
                }
                for (int x = (-range) + 1 + chunkX; x < range + chunkX; x++) {
                    renderChunk(x, chunkZ - range + rangeVal + 1, event);
                }
            }
        }

    }

    private void renderChunk(int x, int z, Render3DEvent event) {
        long chunkKey = ChunkPos.pack(x, z);

        if (chunkRenderers.containsKey(chunkKey)) {
            Map<Ore, Set<Vec3>> chunk = chunkRenderers.get(chunkKey);

            for (Map.Entry<Ore, Set<Vec3>> oreRenders : chunk.entrySet()) {
                if (oreRenders.getKey().active.get()) {
                    for (Vec3 pos : oreRenders.getValue()) {
                        event.renderer.boxLines(pos.x, pos.y, pos.z, pos.x + 1, pos.y + 1, pos.z + 1, oreRenders.getKey().color, 0);
                    }
                }
            }
        }
    }

    @EventHandler
    private void onBlockUpdate(BlockUpdateEvent event) {
        if (event.newState.canOcclude()) return;

        long chunkKey = ChunkPos.pack(event.pos);
        if (chunkRenderers.containsKey(chunkKey)) {
            Vec3 pos = Vec3.atLowerCornerOf(event.pos);
            for (var ore : chunkRenderers.get(chunkKey).values()) {
                ore.remove(pos);
            }
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.level == null || oreConfig == null) return;

        // 直接开挖功能
        if (directMine.get() && BaritoneUtils.IS_AVAILABLE) {
            tickCounter++;
            int intervalTicks = updateInterval.get() * 20; // 转换为tick数

            if (tickCounter >= intervalTicks) {
                tickCounter = 0;
                setNearestMiningTarget();
            }
        }

        List<BlockPos> tempGoals = new ArrayList<>();
        int rangeVal = 4;
        var chunkPos = mc.player.chunkPosition();

        for (int range = 0; range <= rangeVal; ++range) {
            for (int x = -range + chunkPos.x(); x <= range + chunkPos.x(); ++x) {
                tempGoals.addAll(addToBaritone(x, chunkPos.z() + range - rangeVal));
            }
            for (int x = -range + 1 + chunkPos.x(); x < range + chunkPos.x(); ++x) {
                tempGoals.addAll(addToBaritone(x, chunkPos.z() - range + rangeVal + 1));
            }
        }

        if (low.get()) {
            tempGoals.removeIf(p -> p.getY() < 7 || p.getY() > 30);
        }

        if (diamond.get()) {
            tempGoals.removeIf(p -> p.getY() < -58 || p.getY() > -10);
        }

        // 曼哈顿距离排序
        tempGoals.sort(Comparator.comparingInt(p ->
            Math.abs(p.getX() - mc.player.getBlockX()) + Math.abs(p.getZ() - mc.player.getBlockZ())
        ));

        MagicMix.oreGoals.addAll(tempGoals);
    }

    private ArrayList<BlockPos> addToBaritone(int chunkX, int chunkZ) {
        ArrayList<BlockPos> baritoneGoals = new ArrayList<>();
        long chunkKey = ChunkPos.pack(chunkX, chunkZ);
        if (this.chunkRenderers.containsKey(chunkKey)) {
            this.chunkRenderers.get(chunkKey).entrySet().stream()
                .filter(entry -> entry.getKey().active.get())
                .flatMap(entry -> entry.getValue().stream())
                .map(BlockPos::containing)
                .forEach(baritoneGoals::add);
        }
        return baritoneGoals;
    }

    private void setNearestMiningTarget() {
        if (mc.player == null || !BaritoneUtils.IS_AVAILABLE) return;

        // 收集所有可用的矿石目标
        List<BlockPos> allTargets = new ArrayList<>();
        int rangeVal = 8; // 扩大搜索范围
        var chunkPos = mc.player.chunkPosition();

        for (int range = 0; range <= rangeVal; ++range) {
            for (int x = -range + chunkPos.x(); x <= range + chunkPos.x(); ++x) {
                allTargets.addAll(addToBaritone(x, chunkPos.z() + range - rangeVal));
            }
            for (int x = -range + 1 + chunkPos.x(); x < range + chunkPos.x(); ++x) {
                allTargets.addAll(addToBaritone(x, chunkPos.z() - range + rangeVal + 1));
            }
        }

        if (allTargets.isEmpty()) return;

        // 按曼哈顿距离排序
        allTargets.sort(Comparator.comparingInt(p ->
            Math.abs(p.getX() - mc.player.getBlockX()) +
                Math.abs(p.getY() - mc.player.getBlockY()) +
                Math.abs(p.getZ() - mc.player.getBlockZ())
        ));

        // 获取最近的目标
        BlockPos nearestTarget = allTargets.get(0);

        BetterBlockPos betterBlockPos = BetterBlockPos.from(nearestTarget);

        List<String> ores = Ore.oreSettings.stream()
            .filter(setting -> setting.get())
            .map(setting -> setting.description)
            .map(setting -> setting.toLowerCase())
            .toList();

        // 设置Baritone挖掘目标
        try {
            if (!BaritoneAPI.getProvider().getPrimaryBaritone().getMineProcess().isActive()) {
                info("设置挖掘目标: " + nearestTarget.getX() + ", " + nearestTarget.getY() + ", " + nearestTarget.getZ());

                BaritoneAPI.getProvider().getPrimaryBaritone().getMineProcess().mineByName(ores.toArray(new String[]{}));
            }
        } catch (Exception e) {
            info("设置挖掘目标失败" + e);
        }

//        BaritoneAPI.getProvider().getPrimaryBaritone().getCustomGoalProcess().setGoalAndPath(betterBlockPos);

    }


    private void onApplySeedChanged(boolean value) {
        if (value) {
            String seed = seedInput.get();
            if (!seed.isEmpty()) {
                Seeds.get().setSeed(seed, mcVersion.get());
                info("已设置种子: " + seed + " 版本: " + mcVersion.get().name);
                reload();
            } else {
                error("请先输入种子");
            }
            applySeed.set(false);
        }
    }

    @Override
    public void onActivate() {
        super.onActivate();
        if (Seeds.get().getSeed() == null) {
            error("未找到种子。请在种子设置中输入种子并点击应用");
            this.toggle();
            return;
        }

        if (PathManagers.get() instanceof NopPathManager) {
            info("需要 Baritone");
            toggle();
            return;
        }

        info("注意种子是否正确。当前种子: " + Seeds.get().getSeed().seed + " 版本: " + mcVersion.get().name);

        reload();
    }

    @Override
    public void onDeactivate() {
        this.chunkRenderers.clear();
        this.oreConfig = null;
    }


//    @EventHandler
//    private void onPlayerRespawn(PlayerRespawnEvent event) {
//        reload();
//    }

    private void loadVisibleChunks() {
        if (mc.player == null) {
            return;
        }

        for (ChunkAccess chunk : Utils.chunks(false)) {
            doMathOnChunk(chunk);
        }
    }

    private void reload() {
        Seed seed = Seeds.get().getSeed();
        if (seed == null) return;
        worldSeed = seed;
        oreConfig = Ore.getRegistry(PlayerUtils.getDimension());
        MagicMix.oreGoals.clear();
        chunkRenderers.clear();
        if (mc.level != null && worldSeed != null) {
            loadVisibleChunks();
        }
    }

    @EventHandler
    public void onChunkData(ChunkDataEvent event) {
        doMathOnChunk(event.chunk());
    }

    private void doMathOnChunk(ChunkAccess chunk) {

        var chunkPos = chunk.getPos();
        long chunkKey = chunkPos.pack();

        ClientLevel world = mc.level;

        if (chunkRenderers.containsKey(chunkKey) || world == null) {
            return;
        }

        Set<ResourceKey<Biome>> biomes = new HashSet<>();
        ChunkPos.rangeClosed(chunkPos, 1).forEach(chunkPosx -> {
            ChunkAccess chunkxx = world.getChunk(chunkPosx.x(), chunkPosx.z(), ChunkStatus.BIOMES, false);
            if (chunkxx == null) return;

            for (LevelChunkSection chunkSection : chunkxx.getSections()) {
                chunkSection.getBiomes().getAll(entry -> biomes.add(entry.unwrapKey().get()));
            }
        });
        Set<Ore> oreSet = biomes.stream().flatMap(b -> getDefaultOres(b).stream()).collect(Collectors.toSet());

        int chunkX = chunkPos.x() << 4;
        int chunkZ = chunkPos.z() << 4;
        WorldgenRandom random = new WorldgenRandom(new LegacyRandomSource(0));

        long populationSeed = random.setDecorationSeed(worldSeed.seed, chunkX, chunkZ);
        HashMap<Ore, Set<Vec3>> h = new HashMap<>();

        for (Ore ore : oreSet) {

            HashSet<Vec3> ores = new HashSet<>();

            random.setFeatureSeed(populationSeed, ore.index, ore.step);

            int repeat = ore.count.sample(random);

            for (int i = 0; i < repeat; i++) {

                if (ore.rarity != 1F && random.nextFloat() >= 1 / ore.rarity) {
                    continue;
                }

                int x = random.nextInt(16) + chunkX;
                int z = random.nextInt(16) + chunkZ;
                int y = ore.heightProvider.sample(random, ore.heightContext);
                BlockPos origin = new BlockPos(x, y, z);

                ResourceKey<Biome> biome = world.getBiome(new BlockPos(x, y, z)).unwrapKey().get();

                if (!getDefaultOres(biome).contains(ore)) {
                    continue;
                }

                if (ore.scattered) {
                    ores.addAll(generateHidden(world, random, origin, ore.size));
                } else {
                    ores.addAll(generateNormal(world, random, origin, ore.size, ore.discardOnAirChance));
                }
            }
            if (!ores.isEmpty()) {
                h.put(ore, ores);
            }
        }
        chunkRenderers.put(chunkKey, h);
    }

    private List<Ore> getDefaultOres(ResourceKey<Biome> biomeRegistryKey) {
        if (oreConfig.containsKey(biomeRegistryKey)) {
            return oreConfig.get(biomeRegistryKey);
        } else {
            return this.oreConfig.values().stream().findAny().get();
        }
    }

    // ====================================
    // Mojang code
    // ====================================

    private ArrayList<Vec3> generateNormal(ClientLevel world, WorldgenRandom random, BlockPos blockPos, int veinSize, float discardOnAir) {
        float f = random.nextFloat() * 3.1415927F;
        float g = (float) veinSize / 8.0F;
        int i = Mth.ceil(((float) veinSize / 16.0F * 2.0F + 1.0F) / 2.0F);
        double d = (double) blockPos.getX() + Math.sin(f) * (double) g;
        double e = (double) blockPos.getX() - Math.sin(f) * (double) g;
        double h = (double) blockPos.getZ() + Math.cos(f) * (double) g;
        double j = (double) blockPos.getZ() - Math.cos(f) * (double) g;
        double l = (blockPos.getY() + random.nextInt(3) - 2);
        double m = (blockPos.getY() + random.nextInt(3) - 2);
        int n = blockPos.getX() - Mth.ceil(g) - i;
        int o = blockPos.getY() - 2 - i;
        int p = blockPos.getZ() - Mth.ceil(g) - i;
        int q = 2 * (Mth.ceil(g) + i);
        int r = 2 * (2 + i);

        for (int s = n; s <= n + q; ++s) {
            for (int t = p; t <= p + q; ++t) {
                if (o <= world.getHeight(Heightmap.Types.MOTION_BLOCKING, s, t)) {
                    return this.generateVeinPart(world, random, veinSize, d, e, h, j, l, m, n, o, p, q, r, discardOnAir);
                }
            }
        }

        return new ArrayList<>();
    }

    private ArrayList<Vec3> generateVeinPart(ClientLevel world, WorldgenRandom random, int veinSize, double startX, double endX, double startZ, double endZ, double startY, double endY, int x, int y, int z, int size, int i, float discardOnAir) {

        BitSet bitSet = new BitSet(size * i * size);
        BlockPos.MutableBlockPos mutable = new BlockPos.MutableBlockPos();
        double[] ds = new double[veinSize * 4];

        ArrayList<Vec3> poses = new ArrayList<>();

        int n;
        double p;
        double q;
        double r;
        double s;
        for (n = 0; n < veinSize; ++n) {
            float f = (float) n / (float) veinSize;
            p = Mth.lerp(f, startX, endX);
            q = Mth.lerp(f, startY, endY);
            r = Mth.lerp(f, startZ, endZ);
            s = random.nextDouble() * (double) veinSize / 16.0D;
            double m = ((double) (Mth.sin(3.1415927F * f) + 1.0F) * s + 1.0D) / 2.0D;
            ds[n * 4] = p;
            ds[n * 4 + 1] = q;
            ds[n * 4 + 2] = r;
            ds[n * 4 + 3] = m;
        }

        for (n = 0; n < veinSize - 1; ++n) {
            if (!(ds[n * 4 + 3] <= 0.0D)) {
                for (int o = n + 1; o < veinSize; ++o) {
                    if (!(ds[o * 4 + 3] <= 0.0D)) {
                        p = ds[n * 4] - ds[o * 4];
                        q = ds[n * 4 + 1] - ds[o * 4 + 1];
                        r = ds[n * 4 + 2] - ds[o * 4 + 2];
                        s = ds[n * 4 + 3] - ds[o * 4 + 3];
                        if (s * s > p * p + q * q + r * r) {
                            if (s > 0.0D) {
                                ds[o * 4 + 3] = -1.0D;
                            } else {
                                ds[n * 4 + 3] = -1.0D;
                            }
                        }
                    }
                }
            }
        }

        for (n = 0; n < veinSize; ++n) {
            double u = ds[n * 4 + 3];
            if (!(u < 0.0D)) {
                double v = ds[n * 4];
                double w = ds[n * 4 + 1];
                double aa = ds[n * 4 + 2];
                int ab = Math.max(Mth.floor(v - u), x);
                int ac = Math.max(Mth.floor(w - u), y);
                int ad = Math.max(Mth.floor(aa - u), z);
                int ae = Math.max(Mth.floor(v + u), ab);
                int af = Math.max(Mth.floor(w + u), ac);
                int ag = Math.max(Mth.floor(aa + u), ad);

                for (int ah = ab; ah <= ae; ++ah) {
                    double ai = ((double) ah + 0.5D - v) / u;
                    if (ai * ai < 1.0D) {
                        for (int aj = ac; aj <= af; ++aj) {
                            double ak = ((double) aj + 0.5D - w) / u;
                            if (ai * ai + ak * ak < 1.0D) {
                                for (int al = ad; al <= ag; ++al) {
                                    double am = ((double) al + 0.5D - aa) / u;
                                    if (ai * ai + ak * ak + am * am < 1.0D) {
                                        int an = ah - x + (aj - y) * size + (al - z) * size * i;
                                        if (!bitSet.get(an)) {
                                            bitSet.set(an);
                                            mutable.set(ah, aj, al);
                                            if (aj >= -64 && aj < 320 && (world.getBlockState(mutable).canOcclude())) {
                                                if (shouldPlace(world, mutable, discardOnAir, random)) {
                                                    poses.add(new Vec3(ah, aj, al));
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        return poses;
    }

    private boolean shouldPlace(ClientLevel world, BlockPos orePos, float discardOnAir, WorldgenRandom random) {
        if (discardOnAir == 0F || (discardOnAir != 1F && random.nextFloat() >= discardOnAir)) {
            return true;
        }

        for (Direction direction : Direction.values()) {
            if (!world.getBlockState(orePos.offset(direction.getUnitVec3i())).canOcclude() && discardOnAir != 1F) {
                return false;
            }
        }
        return true;
    }

    private ArrayList<Vec3> generateHidden(ClientLevel world, WorldgenRandom random, BlockPos blockPos, int size) {

        ArrayList<Vec3> poses = new ArrayList<>();

        int i = random.nextInt(size + 1);

        for (int j = 0; j < i; ++j) {
            size = Math.min(j, 7);
            int x = this.randomCoord(random, size) + blockPos.getX();
            int y = this.randomCoord(random, size) + blockPos.getY();
            int z = this.randomCoord(random, size) + blockPos.getZ();
            if (world.getBlockState(new BlockPos(x, y, z)).canOcclude()) {
                if (shouldPlace(world, new BlockPos(x, y, z), 1F, random)) {
                    poses.add(new Vec3(x, y, z));
                }
            }
        }

        return poses;
    }

    private int randomCoord(WorldgenRandom random, int size) {
        return Math.round((random.nextFloat() - random.nextFloat()) * (float) size);
    }
}
