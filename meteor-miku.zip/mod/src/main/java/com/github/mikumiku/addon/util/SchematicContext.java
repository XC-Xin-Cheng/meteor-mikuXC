package com.github.mikumiku.addon.util;

import com.google.gson.Gson;
import fi.dy.masa.litematica.world.WorldSchematic;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;

public class SchematicContext {
    public final Level world;
    public final WorldSchematic schematic;
    public final BlockPos blockPos;
    public final BlockState targetState;
    public final BlockState currentState;

    public SchematicContext(Level world, WorldSchematic schematic, BlockPos blockPos) {
        this.world = world;
        this.schematic = schematic;
        this.blockPos = blockPos;
        this.targetState = schematic.getBlockState(blockPos);
        this.currentState = world.getBlockState(blockPos);
    }

    public SchematicContext offset(Direction direction) {
        return new SchematicContext(this.world, this.schematic, this.blockPos.relative(direction));
    }

    @Override
    public String toString() {
        return new Gson().toJson(this);
    }
}

