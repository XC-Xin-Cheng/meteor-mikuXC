package com.github.mikumiku.addon.util.seeds;

import com.seedfinding.mccore.version.MCVersion;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.LongTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.ChatFormatting;

import java.util.Optional;

public class Seed {
    public final Long seed;
    public final MCVersion version;

    public Seed(Long seed, MCVersion version) {
        this.seed = seed;
        if (version == null)
            version = MCVersion.latest();
        this.version = version;
    }

    public CompoundTag toTag() {
        CompoundTag tag = new CompoundTag();
        tag.put("seed", LongTag.valueOf(seed));
        tag.put("version", StringTag.valueOf(version.name));
        return tag;
    }

    public static Seed fromTag(CompoundTag tag) {
        Object version1 = tag.getString("version");
        String key;
        if (version1 instanceof Optional<?> v) {
            key = (String) v.get();
        }else {
            key = (String) version1;
        }

        Object seed1 = tag.getLong("seed");
        Long key2;
         if (seed1 instanceof Optional<?> s) {
            key2 = (Long) s.get();
        }else {
            key2 = (Long) seed1;
        }

        return new Seed(
            key2,
            MCVersion.fromString(key)
        );
    }

//    public Component toText() {
//        MutableComponent text = Component.literal(String.format("[%s%s%s] (%s)",
//            ChatFormatting.GREEN,
//            seed.toString(),
//            ChatFormatting.WHITE,
//            version.toString()
//        ));
//        text.setStyle(text.getStyle()
//            .withClickEvent(new ClickEvent(
//                ClickEvent.Action.COPY_TO_CLIPBOARD,
//                seed.toString()
//            ))
//            .withHoverEvent(new HoverEvent(
//                HoverEvent.Action.SHOW_TEXT,
//                Component.literal("Copy to clipboard")
//            ))
//        );
//        return text;
//    }
}
